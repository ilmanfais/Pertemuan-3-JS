// ini adalah output berupa alert
alert("Selamat datang di tugas pertemuan 3");

// ini adalah variabel nama untuk inputan nama
let nama = prompt("Masukkan nama kamu")

// ini adalah variabel penyelasaian untuk inputan penyelesaian
let penyelesaian = prompt("masukkan 2 jika selesai, masukkan 0 jika belum selesai")

// ini adalah variabel yakin untuk mengecek apakah sudah mengerjakan tugas
let yakin = confirm("Apakah kamu yakin sudah mengerjakan tugas?");

// // ini adalah variabel hasil untuk mengecek apakah kamu sudah mengerjakan tugas atau belum kemudian memberikan output
let hasil = penyelesaian == "2" ? "Kamu Telah Selesai" : "Kamu Belum Selesai"

// ini adalah output berupa alert
document.getElementsByTagName("h1")[0].innerText = hasil